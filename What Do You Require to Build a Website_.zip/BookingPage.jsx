import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Calendar } from '@/components/ui/calendar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { CheckCircle, Clock, MapPin, User, Calendar as CalendarIcon, ArrowLeft, ArrowRight } from 'lucide-react'
import { getServiceById } from '../data/services'

const BookingPage = ({ onBooking }) => {
  const { service: serviceId } = useParams()
  const navigate = useNavigate()
  const service = getServiceById(serviceId)
  
  const [currentStep, setCurrentStep] = useState(1)
  const [bookingData, setBookingData] = useState({
    service: null,
    package: null,
    date: null,
    timeSlot: '',
    contactInfo: {
      name: '',
      email: '',
      phone: '',
      address: '',
      specialRequests: ''
    }
  })

  useEffect(() => {
    if (service) {
      setBookingData(prev => ({ ...prev, service }))
    }
  }, [service])

  const steps = [
    'Service Selection',
    'Package Selection', 
    'Date Selection',
    'Time Selection',
    'Contact Information',
    'Confirmation',
    'Success'
  ]

  const timeSlots = [
    '6:00 AM - 8:00 AM',
    '8:00 AM - 10:00 AM', 
    '10:00 AM - 12:00 PM',
    '4:00 PM - 6:00 PM',
    '6:00 PM - 8:00 PM'
  ]

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handlePackageSelect = (packageData) => {
    setBookingData(prev => ({ ...prev, package: packageData }))
  }

  const handleDateSelect = (date) => {
    setBookingData(prev => ({ ...prev, date }))
  }

  const handleTimeSelect = (timeSlot) => {
    setBookingData(prev => ({ ...prev, timeSlot }))
  }

  const handleContactInfoChange = (field, value) => {
    setBookingData(prev => ({
      ...prev,
      contactInfo: { ...prev.contactInfo, [field]: value }
    }))
  }

  const handleSubmitBooking = () => {
    const booking = onBooking(bookingData)
    setCurrentStep(7) // Success step
  }

  const isStepValid = () => {
    switch (currentStep) {
      case 1: return bookingData.service !== null
      case 2: return bookingData.package !== null
      case 3: return bookingData.date !== null
      case 4: return bookingData.timeSlot !== ''
      case 5: return bookingData.contactInfo.name && bookingData.contactInfo.email && bookingData.contactInfo.phone
      case 6: return true
      default: return false
    }
  }

  if (!service) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Service Not Found</h1>
          <Button onClick={() => navigate('/services')}>
            Back to Services
          </Button>
        </div>
      </div>
    )
  }

  const renderStepContent = () => {
    switch (currentStep) {
      case 1: // Service Selection
        return (
          <Card>
            <CardHeader>
              <CardTitle>Selected Service</CardTitle>
              <CardDescription>Review your selected service details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-4">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-24 h-24 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h3 className="text-xl font-semibold">{service.title}</h3>
                  <p className="text-muted-foreground mb-2">{service.description}</p>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{service.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-4 w-4" />
                      <span>{service.location}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <User className="h-4 w-4" />
                      <span>{service.deity}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )

      case 2: // Package Selection
        return (
          <Card>
            <CardHeader>
              <CardTitle>Choose Package</CardTitle>
              <CardDescription>Select the package that best suits your needs</CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={bookingData.package?.name || ''}
                onValueChange={(value) => {
                  const selectedPackage = service.packages.find(pkg => pkg.name === value)
                  handlePackageSelect(selectedPackage)
                }}
              >
                <div className="space-y-4">
                  {service.packages.map((pkg) => (
                    <div key={pkg.name} className="flex items-start space-x-3">
                      <RadioGroupItem value={pkg.name} id={pkg.name} className="mt-1" />
                      <Label htmlFor={pkg.name} className="flex-1 cursor-pointer">
                        <div className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-semibold">{pkg.name}</h4>
                            <Badge variant="outline">₹{pkg.price.toLocaleString()}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">{pkg.description}</p>
                          <ul className="text-sm space-y-1">
                            {pkg.includes.map((item, i) => (
                              <li key={i} className="flex items-center space-x-2">
                                <CheckCircle className="h-3 w-3 text-primary" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </CardContent>
          </Card>
        )

      case 3: // Date Selection
        return (
          <Card>
            <CardHeader>
              <CardTitle>Select Date</CardTitle>
              <CardDescription>Choose your preferred date for the service</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={bookingData.date}
                  onSelect={handleDateSelect}
                  disabled={(date) => date < new Date() || date < new Date("1900-01-01")}
                  className="rounded-md border"
                />
              </div>
              {bookingData.date && (
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="text-sm">
                    <strong>Selected Date:</strong> {bookingData.date.toLocaleDateString('en-IN', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )

      case 4: // Time Selection
        return (
          <Card>
            <CardHeader>
              <CardTitle>Select Time Slot</CardTitle>
              <CardDescription>Choose your preferred time for the service</CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup value={bookingData.timeSlot} onValueChange={handleTimeSelect}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {timeSlots.map((slot) => (
                    <div key={slot} className="flex items-center space-x-2">
                      <RadioGroupItem value={slot} id={slot} />
                      <Label htmlFor={slot} className="flex-1 cursor-pointer">
                        <div className="border rounded-lg p-3 hover:bg-muted/50 transition-colors">
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4 text-primary" />
                            <span>{slot}</span>
                          </div>
                        </div>
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </CardContent>
          </Card>
        )

      case 5: // Contact Information
        return (
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
              <CardDescription>Please provide your contact details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={bookingData.contactInfo.name}
                    onChange={(e) => handleContactInfoChange('name', e.target.value)}
                    placeholder="Enter your full name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={bookingData.contactInfo.phone}
                    onChange={(e) => handleContactInfoChange('phone', e.target.value)}
                    placeholder="Enter your phone number"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={bookingData.contactInfo.email}
                  onChange={(e) => handleContactInfoChange('email', e.target.value)}
                  placeholder="Enter your email address"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Textarea
                  id="address"
                  value={bookingData.contactInfo.address}
                  onChange={(e) => handleContactInfoChange('address', e.target.value)}
                  placeholder="Enter your complete address"
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="requests">Special Requests</Label>
                <Textarea
                  id="requests"
                  value={bookingData.contactInfo.specialRequests}
                  onChange={(e) => handleContactInfoChange('specialRequests', e.target.value)}
                  placeholder="Any special requirements or requests"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        )

      case 6: // Confirmation
        return (
          <Card>
            <CardHeader>
              <CardTitle>Booking Confirmation</CardTitle>
              <CardDescription>Please review your booking details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Service Details</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong>Service:</strong> {bookingData.service.title}</p>
                    <p><strong>Package:</strong> {bookingData.package.name}</p>
                    <p><strong>Price:</strong> ₹{bookingData.package.price.toLocaleString()}</p>
                    <p><strong>Duration:</strong> {bookingData.service.duration}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <h4 className="font-semibold">Schedule</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong>Date:</strong> {bookingData.date?.toLocaleDateString('en-IN', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}</p>
                    <p><strong>Time:</strong> {bookingData.timeSlot}</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-semibold">Contact Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <p><strong>Name:</strong> {bookingData.contactInfo.name}</p>
                  <p><strong>Phone:</strong> {bookingData.contactInfo.phone}</p>
                  <p><strong>Email:</strong> {bookingData.contactInfo.email}</p>
                  {bookingData.contactInfo.address && (
                    <p><strong>Address:</strong> {bookingData.contactInfo.address}</p>
                  )}
                </div>
                {bookingData.contactInfo.specialRequests && (
                  <div>
                    <p className="text-sm"><strong>Special Requests:</strong></p>
                    <p className="text-sm text-muted-foreground">{bookingData.contactInfo.specialRequests}</p>
                  </div>
                )}
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  By confirming this booking, you agree to our terms and conditions. 
                  Our team will contact you within 24 hours to finalize the arrangements.
                </p>
              </div>
            </CardContent>
          </Card>
        )

      case 7: // Success
        return (
          <Card className="text-center">
            <CardContent className="pt-6 space-y-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold text-green-600">Booking Confirmed!</h2>
                <p className="text-muted-foreground">
                  Your booking for {bookingData.service.title} has been successfully submitted.
                </p>
              </div>
              
              <div className="bg-muted p-4 rounded-lg text-left">
                <h4 className="font-semibold mb-2">Next Steps:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• Our team will contact you within 24 hours</li>
                  <li>• We'll confirm the final arrangements and timing</li>
                  <li>• Payment can be made on the day of service</li>
                  <li>• You'll receive a confirmation email shortly</li>
                </ul>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button onClick={() => navigate('/')}>
                  Back to Home
                </Button>
                <Button variant="outline" onClick={() => navigate('/services')}>
                  Browse More Services
                </Button>
              </div>
            </CardContent>
          </Card>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center space-y-4 mb-8">
          <Badge className="w-fit mx-auto">Book Service</Badge>
          <h1 className="text-3xl md:text-4xl font-bold">Complete Your Booking</h1>
          <p className="text-xl text-muted-foreground">
            Follow the steps below to book your service
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Step {currentStep} of {steps.length}</span>
            <span className="text-sm text-muted-foreground">{steps[currentStep - 1]}</span>
          </div>
          <Progress value={(currentStep / steps.length) * 100} className="h-2" />
        </div>

        {/* Step Content */}
        <div className="mb-8">
          {renderStepContent()}
        </div>

        {/* Navigation Buttons */}
        {currentStep < 7 && (
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentStep === 1}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>
            
            {currentStep === 6 ? (
              <Button onClick={handleSubmitBooking} disabled={!isStepValid()}>
                Confirm Booking
              </Button>
            ) : (
              <Button onClick={handleNext} disabled={!isStepValid()}>
                Next
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default BookingPage


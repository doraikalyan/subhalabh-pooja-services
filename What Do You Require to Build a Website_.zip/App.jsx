import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './App.css'

// Components
import Header from './components/Header'
import Footer from './components/Footer'
import HomePage from './components/HomePage'
import ServicesPage from './components/ServicesPage'
import ServiceCategoryPage from './components/ServiceCategoryPage'
import ServiceDetailPage from './components/ServiceDetailPage'
import BookingPage from './components/BookingPage'
import AdminDashboard from './components/AdminDashboard'

// Service data
import { serviceCategories, services } from './data/services'

function App() {
  const [bookings, setBookings] = useState([])

  const addBooking = (booking) => {
    const newBooking = {
      ...booking,
      id: Date.now().toString(),
      status: 'pending',
      createdAt: new Date().toISOString()
    }
    setBookings(prev => [...prev, newBooking])
    return newBooking
  }

  return (
    <Router>
      <div className="min-h-screen bg-background">
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/services/:category" element={<ServiceCategoryPage />} />
            <Route path="/services/:category/:service" element={<ServiceDetailPage />} />
            <Route path="/booking/:service" element={<BookingPage onBooking={addBooking} />} />
            <Route path="/dashboard/admin" element={<AdminDashboard bookings={bookings} />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App

